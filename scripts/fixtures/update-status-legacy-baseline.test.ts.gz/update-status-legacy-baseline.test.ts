import { inspect } from 'node:util';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { ClaimsSession } from '../claims/types';
import {
  claimFixture,
  transitionClaimFixture,
  withClaimLifecycle,
} from '../claims/lifecycle-test-support';
import type {
  PaymentAuthorizationState,
  RecoveryDeclineReasonCode,
  RecoveryDecisionType,
} from './types';
import { updateClaimStatusCore } from './update-status';
function createSelectChain() {
  return {
    from: vi.fn(),
    leftJoin: vi.fn(),
    where: vi.fn(),
    limit: vi.fn(),
  };
}
type MockRecoveryAgreement = {
  claimId: string;
  decisionType: RecoveryDecisionType | null;
  declineReasonCode: RecoveryDeclineReasonCode | null;
  decisionNextStatus: 'negotiation' | 'court' | null;
  decisionReason: string | null;
  feePercentage: number | null;
  legalActionCapPercentage: number | null;
  minimumFee: string | null;
  paymentAuthorizationState: PaymentAuthorizationState | null;
  signedAt: Date | null;
  acceptedAt: Date | null;
  successFeeRecoveredAmount: string | null;
  successFeeCurrencyCode: string | null;
  successFeeAmount: string | null;
  successFeeCollectionMethod: 'deduction' | 'payment_method_charge' | 'invoice' | null;
  successFeeDeductionAllowed: boolean | null;
  successFeeHasStoredPaymentMethod: boolean | null;
  successFeeInvoiceDueAt: Date | null;
  successFeeResolvedAt: Date | null;
  successFeeSubscriptionId: string | null;
  termsVersion: string | null;
};
const READY_ACCEPTED_RECOVERY_RECORD: MockRecoveryAgreement = {
  claimId: 'claim-1',
  decisionType: 'accepted',
  declineReasonCode: null,
  decisionNextStatus: 'negotiation',
  decisionReason: 'Clear insurer liability and member approval confirmed.',
  feePercentage: 15,
  legalActionCapPercentage: 25,
  minimumFee: '25.00',
  paymentAuthorizationState: 'authorized',
  signedAt: new Date('2026-03-11T09:00:00Z'),
  acceptedAt: new Date('2026-03-11T09:00:00Z'),
  successFeeRecoveredAmount: '1000.00',
  successFeeCurrencyCode: 'EUR',
  successFeeAmount: '150.00',
  successFeeCollectionMethod: 'payment_method_charge',
  successFeeDeductionAllowed: false,
  successFeeHasStoredPaymentMethod: true,
  successFeeInvoiceDueAt: null,
  successFeeResolvedAt: new Date('2026-03-12T09:00:00Z'),
  successFeeSubscriptionId: 'sub-1',
  termsVersion: '2026-03-v1',
};
const STANDARD_SUBSCRIPTION = {
  id: 'sub-1',
  planId: 'standard',
  planKey: 'tenant-standard-plan',
  currentPeriodStart: new Date('2026-01-01T00:00:00Z'),
  currentPeriodEnd: new Date('2026-12-31T23:59:59Z'),
};
const mocks = vi.hoisted(() => {
  const claimSelectChain = createSelectChain();
  const agreementSelectChain = createSelectChain();
  const subscriptionSelectChain = createSelectChain();
  const serviceUsageExistsSelectChain = createSelectChain();
  const serviceUsageCountSelectChain = createSelectChain();
  const txSelectChain = createSelectChain();
  const txExecute = vi.fn(async query => {
    const rendered = JSON.stringify(query).toLowerCase();
    if (rendered.includes('claim_escalation_agreements') && rendered.includes('for update')) {
      return [
        {
          legalActionCapPercentage: 25,
          paymentAuthorizationState: 'authorized',
          signedAt: new Date('2026-03-11T09:00:00Z'),
        },
      ];
    }
    if (rendered.includes('claim_recovery_no_fee_evidence') && rendered.includes('for update')) {
      return [];
    }
    throw new Error(`unexpected recovery lock query: ${rendered}`);
  });
  const txInsertReturning = vi.fn();
  const txInsertOnConflictDoNothing = vi.fn(() => ({ returning: txInsertReturning }));
  const txInsertValues = vi.fn(() => ({
    onConflictDoNothing: txInsertOnConflictDoNothing,
  }));
  const txInsert = vi.fn(() => ({ values: txInsertValues }));
  const txSelect = vi.fn(() => txSelectChain);
  const txUpdateReturning = vi.fn();
  const txUpdateWhere = vi.fn(() => ({ returning: txUpdateReturning }));
  const txUpdateSet = vi.fn(() => ({ where: txUpdateWhere }));
  const txUpdate = vi.fn(() => ({ set: txUpdateSet }));
  const transaction = vi.fn(async cb =>
    cb({ execute: txExecute, insert: txInsert, select: txSelect, update: txUpdate })
  );
  return {
    db: {
      query: {
        user: {
          findFirst: vi.fn().mockResolvedValue({ email: 'member@example.com' }),
        },
      },
      select: vi.fn(),
      transaction,
    },
    logAuditEvent: vi.fn(),
    projectClaimStatusAuditProjection: vi.fn(),
    and: vi.fn((...conditions) => ({ op: 'and', conditions })),
    claims: {
      id: 'claims.id',
      tenantId: 'claims.tenant_id',
      branchId: 'claims.branch_id',
      caseLifecycleState: 'claims.case_lifecycle_state',
      category: 'claims.category',
      staffId: 'claims.staff_id',
      assignedAt: 'claims.assigned_at',
      assignedById: 'claims.assigned_by_id',
      lifecycleVersion: 'claims.lifecycle_version',
      recoveryLifecycleState: 'claims.recovery_lifecycle_state',
      status: 'claims.status',
      updatedAt: 'claims.updated_at',
      userId: 'claims.user_id',
    },
    claimEscalationAgreements: {
      claimId: 'claim_escalation_agreements.claim_id',
      decisionType: 'claim_escalation_agreements.decision_type',
      declineReasonCode: 'claim_escalation_agreements.decline_reason_code',
      decisionNextStatus: 'claim_escalation_agreements.decision_next_status',
      decisionReason: 'claim_escalation_agreements.decision_reason',
      feePercentage: 'claim_escalation_agreements.fee_percentage',
      legalActionCapPercentage: 'claim_escalation_agreements.legal_action_cap_percentage',
      minimumFee: 'claim_escalation_agreements.minimum_fee',
      paymentAuthorizationState: 'claim_escalation_agreements.payment_authorization_state',
      signedAt: 'claim_escalation_agreements.signed_at',
      acceptedAt: 'claim_escalation_agreements.accepted_at',
      successFeeRecoveredAmount: 'claim_escalation_agreements.success_fee_recovered_amount',
      successFeeCurrencyCode: 'claim_escalation_agreements.success_fee_currency_code',
      successFeeAmount: 'claim_escalation_agreements.success_fee_amount',
      successFeeCollectionMethod: 'claim_escalation_agreements.success_fee_collection_method',
      successFeeDeductionAllowed: 'claim_escalation_agreements.success_fee_deduction_allowed',
      successFeeHasStoredPaymentMethod:
        'claim_escalation_agreements.success_fee_has_stored_payment_method',
      successFeeInvoiceDueAt: 'claim_escalation_agreements.success_fee_invoice_due_at',
      successFeeResolvedAt: 'claim_escalation_agreements.success_fee_resolved_at',
      successFeeSubscriptionId: 'claim_escalation_agreements.success_fee_subscription_id',
      termsVersion: 'claim_escalation_agreements.terms_version',
    },
    subscriptions: {
      id: 'subscriptions.id',
      tenantId: 'subscriptions.tenant_id',
      userId: 'subscriptions.user_id',
      planId: 'subscriptions.plan_id',
      planKey: 'subscriptions.plan_key',
      currentPeriodStart: 'subscriptions.current_period_start',
      currentPeriodEnd: 'subscriptions.current_period_end',
    },
    serviceUsage: {
      id: 'service_usage.id',
      tenantId: 'service_usage.tenant_id',
      userId: 'service_usage.user_id',
      subscriptionId: 'service_usage.subscription_id',
      serviceCode: 'service_usage.service_code',
      usedAt: 'service_usage.used_at',
    },
    claimStageHistory: {
      id: 'claim_stage_history.id',
      tenantId: 'claim_stage_history.tenant_id',
      claimId: 'claim_stage_history.claim_id',
      fromStatus: 'claim_stage_history.from_status',
      toStatus: 'claim_stage_history.to_status',
      changedById: 'claim_stage_history.changed_by_id',
      changedByRole: 'claim_stage_history.changed_by_role',
      note: 'claim_stage_history.note',
      isPublic: 'claim_stage_history.is_public',
      createdAt: 'claim_stage_history.created_at',
    },
    claimStatusSchema: {
      safeParse: vi.fn((value: { status: string }) => ({
        success: true,
        data: value,
      })),
    },
    eq: vi.fn((left, right) => ({ op: 'eq', left, right })),
    sql: vi.fn((strings: TemplateStringsArray, ...values: unknown[]) => ({
      op: 'sql',
      strings: [...strings],
      values,
    })),
    withTenant: vi.fn((_tenantId, _column, condition) => ({ scoped: true, condition })),
    ensureTenantId: vi.fn(() => 'tenant-1'),
    claimSelectChain,
    agreementSelectChain,
    subscriptionSelectChain,
    serviceUsageExistsSelectChain,
    serviceUsageCountSelectChain,
    txInsert,
    txExecute,
    txSelect,
    txSelectChain,
    txInsertOnConflictDoNothing,
    txInsertReturning,
    txInsertValues,
    txUpdate,
    txUpdateReturning,
    txUpdateSet,
    txUpdateWhere,
  };
});
vi.mock('@interdomestik/database', () => ({
  and: mocks.and,
  appendEvent: vi.fn().mockResolvedValue({ id: 'event-1' }),
  claimEscalationAgreements: mocks.claimEscalationAgreements,
  claimRecoveryNoFeeEvidence: {
    claimId: 'claim_recovery_no_fee_evidence.claim_id',
    documentedAt: 'claim_recovery_no_fee_evidence.documented_at',
    documentedById: 'claim_recovery_no_fee_evidence.documented_by_id',
    reasonCode: 'claim_recovery_no_fee_evidence.reason_code',
    tenantId: 'claim_recovery_no_fee_evidence.tenant_id',
  },
  claimStageHistory: mocks.claimStageHistory,
  claims: mocks.claims,
  db: mocks.db,
  eq: mocks.eq,
  serviceUsage: mocks.serviceUsage,
  relayClaimStatusAuditProjectionEvents: vi.fn(),
  sql: mocks.sql,
  subscriptions: mocks.subscriptions,
}));
vi.mock('@interdomestik/database/tenant-security', () => ({
  withTenant: mocks.withTenant,
}));
vi.mock('@interdomestik/shared-auth', () => ({
  ensureTenantId: mocks.ensureTenantId,
}));
vi.mock('../validators/claims', () => ({
  claimStatusSchema: mocks.claimStatusSchema,
}));

function createSession(options: {
  userId: string;
  branchId?: string | null;
  role?: string;
  tenantId?: string;
}): ClaimsSession {
  const user = {
    id: options.userId,
    role: options.role ?? 'staff',
    tenantId: options.tenantId ?? 'tenant-1',
  };

  if (options.branchId === undefined) {
    return { user } as unknown as ClaimsSession;
  }

  return {
    user: { ...user, branchId: options.branchId },
  } as unknown as ClaimsSession;
}

function mockRecoverySelects(options?: {
  agreement?: Array<MockRecoveryAgreement>;
  claim?: Array<{
    id: string;
    status: string;
    userId: string;
    category: string;
    title?: string;
    staffId?: string | null;
  }>;
  existingClaimUsage?: Array<{ id: string }>;
  matterCount?: Array<{ count: number }>;
  subscription?: Array<typeof STANDARD_SUBSCRIPTION>;
}) {
  mocks.db.select
    .mockReturnValueOnce(mocks.claimSelectChain)
    .mockReturnValueOnce(mocks.agreementSelectChain)
    .mockReturnValueOnce(mocks.subscriptionSelectChain)
    .mockReturnValueOnce(mocks.serviceUsageExistsSelectChain);
  if ((options?.existingClaimUsage?.length ?? 0) === 0) {
    mocks.db.select.mockReturnValueOnce(mocks.serviceUsageCountSelectChain);
  }
  mocks.claimSelectChain.limit.mockResolvedValue(
    (
      options?.claim ?? [
        {
          id: 'claim-1',
          status: 'evaluation',
          userId: 'member-1',
          category: 'vehicle',
          title: 'Vehicle claim',
          staffId: null,
        },
      ]
    ).map(withClaimLifecycle)
  );
  mocks.agreementSelectChain.limit.mockResolvedValue(
    options?.agreement ?? [READY_ACCEPTED_RECOVERY_RECORD]
  );
  mocks.subscriptionSelectChain.limit.mockResolvedValue(
    options?.subscription ?? [STANDARD_SUBSCRIPTION]
  );
  if ((options?.existingClaimUsage?.length ?? 0) === 0) {
    mocks.serviceUsageCountSelectChain.limit.mockResolvedValue(
      options?.matterCount ?? [{ count: 0 }]
    );
  }
  mocks.serviceUsageExistsSelectChain.limit.mockResolvedValue(options?.existingClaimUsage ?? []);
}
async function runNegotiationUpdate(
  overrides: Partial<Parameters<typeof updateClaimStatusCore>[0]> = {},
  deps?: Parameters<typeof updateClaimStatusCore>[1]
) {
  return updateClaimStatusCore(
    {
      claimId: 'claim-1',
      newStatus: 'negotiation',
      session: createSession({ userId: 'staff-1', branchId: 'branch-1' }),
      ...overrides,
    },
    deps ?? { projectClaimStatusAuditProjection: mocks.projectClaimStatusAuditProjection }
  );
}
function expectBlockedStatusChange(
  result: Awaited<ReturnType<typeof updateClaimStatusCore>>,
  error: string
) {
  expect(result).toEqual({
    success: false,
    error,
  });
  expect(mocks.txUpdate).not.toHaveBeenCalled();
}
describe('staff updateClaimStatusCore', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.db.select.mockReset();
    mocks.db.query.user.findFirst.mockResolvedValue({ email: 'member@example.com' });
    mocks.claimSelectChain.from.mockReturnValue(mocks.claimSelectChain);
    mocks.claimSelectChain.where.mockReturnValue(mocks.claimSelectChain);
    mocks.agreementSelectChain.from.mockReturnValue(mocks.agreementSelectChain);
    mocks.agreementSelectChain.where.mockReturnValue(mocks.agreementSelectChain);
    mocks.subscriptionSelectChain.from.mockReturnValue(mocks.subscriptionSelectChain);
    mocks.subscriptionSelectChain.where.mockReturnValue(mocks.subscriptionSelectChain);
    mocks.serviceUsageExistsSelectChain.from.mockReturnValue(mocks.serviceUsageExistsSelectChain);
    mocks.serviceUsageExistsSelectChain.where.mockReturnValue(mocks.serviceUsageExistsSelectChain);
    mocks.serviceUsageCountSelectChain.from.mockReturnValue(mocks.serviceUsageCountSelectChain);
    mocks.serviceUsageCountSelectChain.where.mockReturnValue(mocks.serviceUsageCountSelectChain);
    mocks.txSelectChain.from.mockReturnValue(mocks.txSelectChain);
    mocks.txSelectChain.leftJoin.mockReturnValue(mocks.txSelectChain);
    mocks.txSelectChain.where.mockReturnValue(mocks.txSelectChain);
    mocks.txSelectChain.limit.mockResolvedValue([transitionClaimFixture('evaluation')]);
    mocks.txInsertReturning.mockResolvedValue([{ id: 'usage-claim-1' }]);
    mocks.txUpdateReturning.mockResolvedValue([{ id: 'claim-1', lifecycleVersion: 2 }]);
    mocks.projectClaimStatusAuditProjection.mockResolvedValue(undefined);
  });
  it.each([
    {
      agreement: [] as Array<MockRecoveryAgreement>,
      title: 'blocks negotiation until a recovery decision is recorded',
    },
    {
      agreement: [
        {
          ...READY_ACCEPTED_RECOVERY_RECORD,
          decisionType: null,
        },
      ],
      title: 'blocks negotiation until staff explicitly accept the recovery decision',
    },
  ])('$title', async ({ agreement }) => {
    mockRecoverySelects({ agreement });
    const result = await runNegotiationUpdate();
    expectBlockedStatusChange(
      result,
      'Staff must accept the recovery decision before staff-led recovery can begin.'
    );
  });
  it('blocks negotiation until the accepted escalation agreement is complete', async () => {
    mockRecoverySelects({
      agreement: [
        {
          ...READY_ACCEPTED_RECOVERY_RECORD,
          paymentAuthorizationState: 'pending',
          signedAt: null,
        },
      ],
      claim: [{ id: 'claim-1', status: 'evaluation', userId: 'member-1', category: 'vehicle' }],
    });
    const result = await runNegotiationUpdate();
    expectBlockedStatusChange(
      result,
      'Save the accepted escalation agreement before staff-led recovery can begin.'
    );
  });

  it('blocks negotiation until the accepted case has a saved collection path', async () => {
    mockRecoverySelects({
      agreement: [
        {
          ...READY_ACCEPTED_RECOVERY_RECORD,
          successFeeRecoveredAmount: null,
          successFeeCurrencyCode: null,
          successFeeAmount: null,
          successFeeCollectionMethod: null,
          successFeeDeductionAllowed: null,
          successFeeHasStoredPaymentMethod: null,
          successFeeInvoiceDueAt: null,
          successFeeResolvedAt: null,
          successFeeSubscriptionId: null,
        },
      ],
    });
    const result = await runNegotiationUpdate();
    expectBlockedStatusChange(
      result,
      'Save the success-fee collection path before staff-led recovery can begin.'
    );
  });

  it('blocks negotiation for guidance-only matters before staff-led recovery can begin', async () => {
    mockRecoverySelects({
      claim: [{ id: 'claim-1', status: 'evaluation', userId: 'member-1', category: 'travel' }],
    });
    const result = await runNegotiationUpdate();
    expectBlockedStatusChange(
      result,
      'This matter stays guidance-only or referral-only under the current launch scope and cannot move into staff-led recovery or success-fee handling.'
    );
  });

  it('allows recovery status transition when an accepted case has a valid invoice fallback path', async () => {
    mockRecoverySelects({
      agreement: [
        {
          ...READY_ACCEPTED_RECOVERY_RECORD,
          successFeeCollectionMethod: 'invoice',
          successFeeHasStoredPaymentMethod: false,
          successFeeInvoiceDueAt: new Date('2026-03-19T09:00:00Z'),
          successFeeSubscriptionId: null,
        },
      ],
    });
    const result = await runNegotiationUpdate({
      note: 'member signed the agreement',
    });

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.txUpdateSet).toHaveBeenCalledWith(
      expect.objectContaining({
        caseLifecycleState: 'recovery', recoveryLifecycleState: 'negotiation',
        updatedAt: expect.any(Date),
      })
    );
    expect(mocks.txInsertValues).toHaveBeenCalledWith(
      expect.objectContaining({
        claimId: 'claim-1',
        changedById: 'staff-1',
        changedByRole: 'staff',
        fromStatus: 'evaluation',
        isPublic: true,
        note: 'member signed the agreement',
        tenantId: 'tenant-1',
        toStatus: 'negotiation',
      })
    );
  });

  it('auto-assigns the acting staff member when an unassigned claim is triaged', async () => {
    mocks.db.select.mockReturnValueOnce(mocks.claimSelectChain);
    mocks.claimSelectChain.limit.mockResolvedValue([
      claimFixture('submitted', { title: 'Vehicle claim', staffId: null }),
    ]);

    const result = await updateClaimStatusCore({
      claimId: 'claim-1',
      newStatus: 'verification',
      note: 'Initial staff triage',
      session: createSession({ userId: 'staff-1', branchId: 'branch-1' }),
    });

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.txUpdateSet).toHaveBeenNthCalledWith(
      1,
      expect.objectContaining({
        lifecycleVersion: expect.objectContaining({ op: 'sql' }),
        caseLifecycleState: 'verification', recoveryLifecycleState: 'not_started',
        statusUpdatedAt: expect.any(Date),
        updatedAt: expect.any(Date),
      })
    );
    const [transitionWhereArg] = (mocks.txUpdateWhere.mock.calls[0] ?? []) as unknown[];
    const transitionWhere = inspect(transitionWhereArg, { depth: 20 });
    expect(transitionWhere).toContain('claims.branch_id');
    expect(transitionWhere).toContain('claims.lifecycle_version');
    expect(transitionWhere).toContain('claims.case_lifecycle_state');
    expect(transitionWhere).toContain('claims.recovery_lifecycle_state');
    expect(transitionWhere).not.toContain('claims.status');
    expect(mocks.txUpdateSet).toHaveBeenNthCalledWith(
      2,
      expect.objectContaining({
        staffId: expect.objectContaining({ op: 'sql' }),
        assignedAt: expect.objectContaining({ op: 'sql' }),
        assignedById: expect.objectContaining({ op: 'sql' }),
        updatedAt: expect.any(Date),
      })
    );
    expect(mocks.sql).toHaveBeenNthCalledWith(
      2,
      expect.any(Array),
      mocks.claims.staffId,
      'staff-1'
    );
    expect(mocks.sql).toHaveBeenNthCalledWith(
      3,
      expect.any(Array),
      mocks.claims.assignedAt,
      expect.any(Date)
    );
    expect(mocks.sql).toHaveBeenNthCalledWith(
      4,
      expect.any(Array),
      mocks.claims.assignedById,
      'staff-1'
    );
  });

  it('skips lifecycle-derived same-status requests without writing', async () => {
    const staleClaim = claimFixture('evaluation', { title: 'Vehicle claim', staffId: 'staff-1' });
    staleClaim.status = 'submitted';
    mocks.db.select.mockReturnValueOnce(mocks.claimSelectChain);
    mocks.claimSelectChain.limit.mockResolvedValue([staleClaim]);
    const result = await updateClaimStatusCore({
      claimId: 'claim-1',
      newStatus: 'evaluation',
      session: createSession({ userId: 'staff-1', branchId: 'branch-1' }),
    });

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.db.transaction).not.toHaveBeenCalled();
  });

  it('sends a tenant-scoped notification for public staff status changes', async () => {
    const notifyStatusChanged = vi.fn().mockResolvedValue({ success: true });
    mocks.db.select.mockReturnValueOnce(mocks.claimSelectChain);
    mocks.claimSelectChain.limit.mockResolvedValue([
      claimFixture('submitted', { title: 'Vehicle claim', staffId: 'staff-1' }),
    ]);
    mocks.txSelectChain.limit.mockResolvedValueOnce([transitionClaimFixture('submitted')]);

    const result = await updateClaimStatusCore(
      {
        claimId: 'claim-1',
        newStatus: 'verification',
        session: createSession({ userId: 'staff-1', branchId: 'branch-1' }),
      },
      {
        notifyStatusChanged,
        projectClaimStatusAuditProjection: mocks.projectClaimStatusAuditProjection,
      }
    );

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.projectClaimStatusAuditProjection).toHaveBeenCalledWith({
      limit: 10,
      tenantId: 'tenant-1',
    });
    await vi.waitFor(() =>
      expect(notifyStatusChanged).toHaveBeenCalledWith(
        'member-1',
        'member@example.com',
        { id: 'claim-1', title: 'Vehicle claim' },
        'submitted',
        'verification',
        { tenantId: 'tenant-1' }
      )
    );
  });

  it('denies status changes for claims outside the acting staff scope', async () => {
    mocks.db.select.mockReturnValueOnce(mocks.claimSelectChain);
    mocks.claimSelectChain.limit.mockResolvedValue([]);

    const result = await updateClaimStatusCore({
      claimId: 'claim-1',
      newStatus: 'verification',
      session: createSession({ userId: 'staff-1', branchId: 'branch-1' }),
    });

    expect(result).toEqual({
      success: false,
      error: 'Claim not found or access denied',
    });
    expect(mocks.txUpdate).not.toHaveBeenCalled();
    expect(mocks.txInsert).not.toHaveBeenCalled();
  });

  it('rejects invalid guarded transitions before status, history, or assignment writes', async () => {
    mocks.db.select.mockReturnValueOnce(mocks.claimSelectChain);
    mocks.claimSelectChain.limit.mockResolvedValue([
      claimFixture('submitted', { title: 'Vehicle claim', staffId: null }),
    ]);
    mocks.txSelectChain.limit.mockResolvedValueOnce([
      { id: 'claim-1', lifecycleVersion: 1, status: null },
    ]);

    const result = await updateClaimStatusCore({
      claimId: 'claim-1',
      newStatus: 'verification',
      session: createSession({ userId: 'staff-1', branchId: 'branch-1' }),
    });

    expect(result).toEqual({ success: false, error: 'Failed to update claim status' });
    expect(mocks.txUpdateSet).not.toHaveBeenCalled();
    expect(mocks.txInsertValues).not.toHaveBeenCalled();
  });

  it('blocks recovery status transition after staff accept the recovery decision when agreement terms are still missing', async () => {
    mockRecoverySelects({
      agreement: [
        {
          ...READY_ACCEPTED_RECOVERY_RECORD,
          feePercentage: null,
          legalActionCapPercentage: null,
          minimumFee: null,
          paymentAuthorizationState: 'pending',
          signedAt: null,
          termsVersion: null,
        },
      ],
    });

    const result = await runNegotiationUpdate({
      note: 'Staff accepted the recovery decision and can now start work.',
    });

    expectBlockedStatusChange(
      result,
      'Save the accepted escalation agreement before staff-led recovery can begin.'
    );
  });

  it('skips allowance total and usage window queries when the claim already consumed a recovery matter', async () => {
    mockRecoverySelects({
      existingClaimUsage: [{ id: 'usage-claim-1' }],
    });

    const result = await runNegotiationUpdate();

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.serviceUsageCountSelectChain.limit).not.toHaveBeenCalled();
    expect(mocks.txInsertOnConflictDoNothing).not.toHaveBeenCalled();
  });

  it('blocks staff-led recovery when annual matter allowance is exhausted without an override', async () => {
    mockRecoverySelects({
      matterCount: [{ count: 2 }],
    });

    const result = await runNegotiationUpdate();

    expectBlockedStatusChange(
      result,
      'Matter allowance is exhausted. Record an override reason or upgrade the membership before staff-led recovery can begin.'
    );
    expect(mocks.txInsert).not.toHaveBeenCalledWith(mocks.serviceUsage);
  });

  it('records matter consumption once when staff-led recovery starts within allowance', async () => {
    mockRecoverySelects({
      matterCount: [{ count: 1 }],
    });

    const result = await runNegotiationUpdate({
      note: 'Recovery accepted',
    });

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.txInsert).toHaveBeenCalledWith(mocks.serviceUsage);
    expect(mocks.txInsertOnConflictDoNothing).toHaveBeenCalledWith({
      target: [
        mocks.serviceUsage.tenantId,
        mocks.serviceUsage.subscriptionId,
        mocks.serviceUsage.serviceCode,
      ],
    });
    expect(mocks.txInsertValues).toHaveBeenCalledWith(
      expect.objectContaining({
        serviceCode: 'staff_recovery_matter:claim-1',
        subscriptionId: 'sub-1',
        tenantId: 'tenant-1',
        userId: 'member-1',
      })
    );
  });

  it('allows exhausted allowance when an explicit override reason is recorded', async () => {
    mockRecoverySelects({
      matterCount: [{ count: 2 }],
    });

    const result = await runNegotiationUpdate(
      {
        allowanceOverrideReason: 'Family upgrade is pending but recovery must start now',
      },
      {
        logAuditEvent: mocks.logAuditEvent,
        projectClaimStatusAuditProjection: mocks.projectClaimStatusAuditProjection,
      }
    );

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.txInsert).toHaveBeenCalledWith(mocks.serviceUsage);
    expect(mocks.logAuditEvent).not.toHaveBeenCalled();
    expect(mocks.projectClaimStatusAuditProjection).toHaveBeenCalledWith({
      limit: 10,
      tenantId: 'tenant-1',
    });
  });

  it('treats a conflicting recovery usage insert as an already consumed matter', async () => {
    mockRecoverySelects({
      matterCount: [{ count: 1 }],
    });
    mocks.txInsertReturning.mockResolvedValueOnce([]);

    const result = await runNegotiationUpdate();

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.txInsertOnConflictDoNothing).toHaveBeenCalledWith({
      target: [
        mocks.serviceUsage.tenantId,
        mocks.serviceUsage.subscriptionId,
        mocks.serviceUsage.serviceCode,
      ],
    });
  });

  it('requires an explicit reason when staff reject a recovery matter', async () => {
    mocks.db.select.mockReturnValueOnce(mocks.claimSelectChain);
    mocks.claimSelectChain.limit.mockResolvedValue([claimFixture('negotiation')]);

    const result = await updateClaimStatusCore({
      claimId: 'claim-1',
      newStatus: 'rejected',
      session: createSession({ userId: 'staff-1', branchId: 'branch-1' }),
    });

    expect(result).toEqual({
      success: false,
      error: 'Decline reason category is required when staff reject a recovery matter.',
    });
    expect(mocks.txUpdate).not.toHaveBeenCalled();
    expect(mocks.txInsert).not.toHaveBeenCalled();
  });

  it('activates audit projection when staff decline a recovery matter', async () => {
    const requestHeaders = new Headers({ 'user-agent': 'Vitest' });

    mocks.db.select.mockReturnValueOnce(mocks.claimSelectChain);
    mocks.claimSelectChain.limit.mockResolvedValue([claimFixture('negotiation')]);
    mocks.txSelectChain.limit
      .mockResolvedValueOnce([transitionClaimFixture('negotiation')])
      .mockResolvedValueOnce([]);

    const result = await updateClaimStatusCore(
      {
        claimId: 'claim-1',
        newStatus: 'rejected',
        declineReasonCode: 'no_monetary_recovery_path',
        decisionExplanation: 'Declined after review',
        requestHeaders,
        session: createSession({ userId: 'staff-1', branchId: 'branch-1' }),
      },
      {
        logAuditEvent: mocks.logAuditEvent,
        projectClaimStatusAuditProjection: mocks.projectClaimStatusAuditProjection,
      }
    );

    expect(result).toEqual({ success: true, error: undefined });
    expect(mocks.logAuditEvent).not.toHaveBeenCalled();
    expect(mocks.projectClaimStatusAuditProjection).toHaveBeenCalledWith({
      limit: 10,
      tenantId: 'tenant-1',
    });
  });
});
